<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC <contact@vinades.vn>
 * @Copyright (C) 2018 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Fri, 12 Jan 2018 07:59:54 GMT
 */

if( ! defined( 'NV_IS_FILE_MODULES' ) ) die( 'Stop!!!' );

$sql_drop_module = array();
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data;

$sql_create_module = $sql_drop_module;
$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "(
  id smallint(4) NOT NULL AUTO_INCREMENT,
  first_name varchar(100) NOT NULL,
  last_name varchar(50) NOT NULL,
  gender tinyint(1) unsigned NOT NULL DEFAULT '1',
  birthday int(11) unsigned NOT NULL DEFAULT '0',
  phone varchar(20) NOT NULL,
  email varchar(100) NOT NULL,
  scmnd varchar(100) NOT NULL,
  ngaycap int(11) unsigned NOT NULL DEFAULT '0',
  noicap varchar(100) NOT NULL,
  address varchar(250) NOT NULL,
  image varchar(250) NOT NULL,
  worktype tinyint(1) unsigned NOT NULL DEFAULT '0',
  sobhxh varchar(100) NOT NULL COMMENT 'So xo bhxh',
  sohdld varchar(100) NOT NULL COMMENT 'Hop dong lao dong',
  ngaykyhopdong int(10) unsigned NOT NULL COMMENT 'Ngay ky hop dong',
  ngaynghiviec int(10) unsigned NOT NULL COMMENT 'Ngay nghi viec',
  biensoxe varchar(100) NOT NULL COMMENT 'Bien so xe',
  addtime int(10) unsigned NOT NULL,
  edittime int(10) unsigned NOT NULL DEFAULT '0',
  useradd mediumint(8) unsigned NOT NULL,
  status tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (id)
) ENGINE=MyISAM";


// Cau hinh dang bai ngoai trang
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'group_add_workforce', '')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'group_view_workforce', '')";
