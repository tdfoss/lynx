<?php

/**
 * @Project NUKEVIET 4.x
 * @Author TDFOSS.,LTD (quanglh268@gmail.com)
 * @Copyright (C) 2018 TDFOSS.,LTD. All rights reserved
 * @Createdate Fri, 12 Jan 2018 02:38:03 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = 'TDFOSS.,LTD (quanglh268@gmail.com)';
$lang_translator['createdate'] = '12/01/2018, 02:38';
$lang_translator['copyright'] = '@Copyright (C) 2018 VINADES.,JSC. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['save'] = 'Lưu thay đổi';
$lang_module['main'] = 'Trang chính';
$lang_module['edit'] = 'Sửa';
$lang_module['delete'] = 'Xóa';
$lang_module['detail'] = 'Xem chi tiết';
$lang_module['search'] = 'Tìm kiếm';
$lang_module['workforce'] = 'Quản lý nhân sự';
$lang_module['workforce_add'] = 'Thêm nhân sự';
$lang_module['workforce_edit'] = 'Sửa nhân sự';
$lang_module['fullname'] = 'Họ và tên';
$lang_module['first_name'] = 'Tên';
$lang_module['last_name'] = 'Họ và tên đệm';
$lang_module['birthday'] = 'Ngày sinh';
$lang_module['knowledge'] = 'Thông tin học vấn';
$lang_module['phone'] = 'Số điện thoại';
$lang_module['email'] = 'Email';
$lang_module['address'] = 'Địa chỉ';
$lang_module['scmnd'] = 'Số CMND';
$lang_module['ngaycap'] = 'Ngày cấp';
$lang_module['noicap'] = 'Nơi cấp';
$lang_module['sohdld'] = 'Số hợp đồng LĐ';
$lang_module['ngaykyhopdong'] = 'Ngày ký hợp đồng';
$lang_module['ngaynghiviec'] = 'Ngày nghỉ việc';
$lang_module['sobhxh'] = 'Số sổ BHXH';
$lang_module['image'] = 'Hình ảnh';
$lang_module['biensoxe'] = 'Biển số xe';
$lang_module['thebank'] = 'Thông tin tài khoản ngân hàng';
$lang_module['addtime'] = 'Thời gian thêm';
$lang_module['edittime'] = 'Thời gian cập nhật';
$lang_module['useradd'] = 'Người giao việc';
$lang_module['status'] = 'Trạng thái';
$lang_module['gender'] = 'Giới tính';
$lang_module['male'] = 'Nam';
$lang_module['female'] = 'Nữ';
$lang_module['error_required_first_name'] = 'Lỗi: bạn cần nhập dữ liệu cho Tên';
$lang_module['error_required_last_name'] = 'Lỗi: bạn cần nhập dữ liệu cho Họ và tên đệm';
$lang_module['error_required_gender'] = 'Lỗi: bạn cần nhập dữ liệu cho Giới tính';
$lang_module['error_required_birthday'] = 'Lỗi: bạn cần nhập dữ liệu cho Ngày sinh';
$lang_module['error_required_biensoxe'] = 'Lỗi: bạn cần nhập dữ liệu cho Biển số xe';
$lang_module['error_required_phone'] = 'Lỗi bạn phải nhập dữ liệu số điện thoại';
$lang_module['error_empty_data'] = 'Bạn cần chọn dữ liệu để thực hiện!';
$lang_module['perform'] = 'Thực hiện';
$lang_module['worktype'] = 'Loại hợp đồng';
$lang_module['worktype_0'] = 'Học việc';
$lang_module['worktype_1'] = 'Thử việc';
$lang_module['worktype_2'] = 'Chính thức';
$lang_module['email_title'] = 'Tiêu đề';
$lang_module['email_useradd'] = 'Người gửi';
$lang_module['email_addtime'] = 'Thời gian gửi';
$lang_module['email_add'] = 'Gửi email';
$lang_module['search_submit'] = 'Tìm kiếm';
$lang_module['search_data'] = 'Để con trỏ chuột vào ô và quét thẻ hoặc nhập ID và tìm kiếm';
$lang_module['avatar'] = 'Hình đại diện';
$lang_module['avatar_pagetitle'] = 'Tải lên hình đại diện';
$lang_module['avatar_bigfile'] = 'Dung lượng file cho phép: <= %1$s';
$lang_module['avatar_bigsize'] = 'Kích thước ảnh lớn nhất cho phép (px): %1$s x %2$s';
$lang_module['avatar_smallsize'] = 'Kích thước tối thiểu của hình là (px): %1$s x %2$s';
$lang_module['avatar_filetype'] = 'Định dạng file cho phép: *.jpg, *.png';
$lang_module['avatar_filesize'] = 'Dung lượng';
$lang_module['avatar_ftype'] = 'Kiểu';
$lang_module['avatar_filedimension'] = 'Kích thước thực tế';
$lang_module['avatar_displaydimension'] = 'Kích thước hiển thị';
$lang_module['avatar_guide'] = 'Để thay đổi hình đại diện hãy thực hiện theo các bước';
$lang_module['avatar_crop'] = 'Cắt hình';
$lang_module['avatar_chosen'] = 'Chọn hình bằng cách click vào ô bên';
$lang_module['avatar_chosen_other'] = 'Chọn hình khác';
$lang_module['avatar_upload'] = 'Chọn vùng hiển thị sau đó nhấn "Cắt hình"';
$lang_module['avatar_delete'] = 'Xóa hình đại diện';
$lang_module['avatar_clear'] = 'Xóa trắng';
$lang_module['avatar_select_img'] = 'Nhấn vào đây để chọn hình';
$lang_module['avatar_error_data'] = 'Lỗi: Dữ liệu không đầy đủ, vui lòng thực hiện lại';
$lang_module['avatar_error_save'] = 'Lỗi: Hệ thống không thực hiện được yêu cầu, vui lòng thử lại';
$lang_module['avatar_old_not_exists'] = 'Hình đại diện cũ không tồn tại';
$lang_module['avatar_news_not_exists'] = 'Hình đại diện đã chọn không tồn tại';
$lang_module['avatar_news_copy_error'] = 'Không thể lưu hình đại diện';
