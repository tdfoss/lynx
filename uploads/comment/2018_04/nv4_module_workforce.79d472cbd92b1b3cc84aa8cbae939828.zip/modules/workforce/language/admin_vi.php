<?php

/**
 * @Project NUKEVIET 4.x
 * @Author TDFOSS.,LTD (quanglh268@gmail.com)
 * @Copyright (C) 2018 TDFOSS.,LTD. All rights reserved
 * @Createdate Fri, 12 Jan 2018 02:38:03 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = 'TDFOSS.,LTD (quanglh268@gmail.com)';
$lang_translator['createdate'] = '12/01/2018, 02:38';
$lang_translator['copyright'] = '@Copyright (C) 2018 TDFOSS.,LTD All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['main'] = 'Trang chính';
$lang_module['config'] = 'Cấu hình';
$lang_module['save'] = 'Save';

$lang_module['group_view_workforce'] = 'Nhóm được quét thẻ';
$lang_module['group_add_workforce'] = 'Nhóm được thêm/quẩn lý nhân viên';
