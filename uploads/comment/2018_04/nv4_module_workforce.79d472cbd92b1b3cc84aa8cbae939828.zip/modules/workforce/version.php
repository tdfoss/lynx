<?php

/**
 * @Project NUKEVIET 4.x
 * @Author TDFOSS.,LTD (kid.apt@gmail.com)
 * @Copyright (C) 2018 TDFOSS.,LTD. All rights reserved
 * @Createdate Fri, 12 Jan 2018 02:38:03 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$module_version = array(
	'name' => 'Workforce',
	'modfuncs' => 'main,list,content,avatar',
	'change_alias' => 'main,list,content',
	'submenu' => 'main,list,content',
	'is_sysmod' => 0,
	'virtual' => 1,
	'version' => '1.0.01',
	'date' => 'Fri, 12 Jan 2018 02:38:03 GMT',
	'author' => 'TDFOSS.,LTD (kid.apt@gmail.com)',
	'uploads_dir' => array($module_name),
	'note' => ''
);